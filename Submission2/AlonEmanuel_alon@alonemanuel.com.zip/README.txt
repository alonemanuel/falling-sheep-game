Objective:
Control the sheep and collect all the pickups on board.
Try to avoid falling into space and hitting the bombs.